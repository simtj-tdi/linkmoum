<?php
$menu["menu950"] = array (
    array('950000', 'MWB 관리', ''.MWB_ADMIN_URL.'/notice.php', 'mwb'),
    array('950000', 'MWB 설명', ''.MWB_ADMIN_URL.'/notice.php', 'mwb'),
    array('950050', 'MWB SEO 관리', ''.MWB_ADMIN_URL.'/seo.php', 'mwb_seo'),
);
?>